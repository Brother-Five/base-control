 #include "UsartFrame_STM32.h"
 #include "RTL.h"
#include "bsp.h"
#include "stdarg.h"
#include "stdio.h"
#include "string.h"
#include "cpid.h"
#include "SetParameter.h"

FUZZYPID CVPID(8.5,0.1,1.1,0,-4500, +4500, -3000, +3000, -4500, +4500,-500,500,0.0,5,\
		 100.0f,50.0f,20.0f,\
//		 0.3f,0.6f,0.5f,\
		 0.0f,0.0f,0.0f,\
		 0.8,1.0,0.8);
		  0.5f,0.5f,0.5f,\
//		 0.4f,0.2f,0.25f,
		 1.0f,1.5f,3.0f,\
		 0.1,0.1,0.1);
FUZZYPID CVPitchPID(8.5,0.1,1.1,0,-4500, +4500, -3000, +3000, -4500, +4500,-500,500,0.0,5,\
		 100.0f,50.0f,20.0f,\
//		 0.3f,0.6f,0.5f,\
		 0.0f,0.0f,0.0f,\
		 0.8,1.0,0.8);
		  0.5f,0.5f,0.5f,\
//		 0.4f,0.2f,0.25f,
		 1.0f,1.5f,3.0f,\
		 0.1,0.1,0.1);
//CPID CVPID(0.0,1.0,0.0,0,-4500, +4500, -2000, +2000, -4500, +4500,-500,500,5.0,5);
os_mbx_declare(UsartFrame_mailbox,1024);

/**
 * [UsasrFrameInit ʹ��STM32CRC32��ʱ��]
 */
void UsasrFrameInit(void)
{
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_CRC, ENABLE);
}


/**
 * [CRC_STM32Hard STM32Ӳ��CRC32,���ݳ��ȱ�����4�ı���(STM32��32λ��)]
 * @param  pBuffer      [����ָ��]
 * @param  BufferLength [���ݳ���]
 * @return              [CRC32У����]
 */
uint32_t CRC_STM32Hard(uint8_t* pBuffer, uint32_t BufferLength)
{
  uint32_t i;
//  uint32_t temp = ((BufferLength-1)>>2) + 1;//����4
  uint32_t temp = BufferLength>>2;
  uint32_t tempcount;
  CRC->CR = CRC_CR_RESET;
//  if(BufferLength%4)
  for(i = 0; i < temp; i++)
  {
	tempcount = i<<2;
    CRC->DR = pBuffer[tempcount]<<24 | pBuffer[tempcount+1]<<16 | pBuffer[tempcount+2]<<8 | pBuffer[tempcount+3];
  }
  return (CRC->DR);
}



/**
 * [CRC_STM32Check STM32CRC32���,���ݳ��ȱ�����4�ı���(STM32��32λ��)]
 * @param  pBuffer      [����ָ��]
 * @param  BufferLength [���ݳ���]
 * @param  CRC32Rec     [���յ�CRC32У����]
 * @return              [0:��ȷ�����룬OTHERS:�����룬�����д���]
 */
uint32_t CRC_STM32Check(uint8_t* pBuffer, uint32_t BufferLength , uint32_t CRC32Rec)
{
  uint32_t i;
//  uint32_t temp = ((BufferLength-1)>>2) + 1;//����4
  uint32_t temp = BufferLength>>2;
  uint32_t tempcount;
  CRC->CR = CRC_CR_RESET;
  for(i = 0; i < temp; i++)
  {
	tempcount = i<<2;//����4
    CRC->DR = pBuffer[tempcount]<<24 | pBuffer[tempcount+1]<<16 | pBuffer[tempcount+2]<<8 | pBuffer[tempcount+3];//1|2|3|4ת����С�˸�ʽ
  }
  CRC->DR = CRC32Rec;//�����CRC32У����
  return (CRC->DR);
}


/**
 * [UsasrFrameSend Э�鷢�ͺ���]
 * @param pBuffer [���ͽṹ���ָ��]
 */
void UsasrFrameSend(FRAME * pBuffer)
{
	unsigned char i,temp;
	pBuffer->SOF = 0xAA;
	temp = (pBuffer->LEN)%4;
	if(temp)
		pBuffer->MOD = 4 - temp;
	else
		pBuffer->MOD = 0;
	for (i = 0; i < pBuffer->MOD; ++i)
	{
		pBuffer->DATA[pBuffer->LEN + i] = 0xff;
	}
	pBuffer->CRC32 = CRC_STM32Hard(pBuffer->DATA,pBuffer->LEN + pBuffer->MOD);
	USART1_DMA_Send((uint8_t*)pBuffer,pBuffer->LEN + pBuffer->MOD + 8);
}

/**
 * [senddemo ����ʵ��]
 */
void senddemo(void)
{
	FRAME Ftemp;
	Ftemp.LEN = 0x07;
	Ftemp.DATA[0] = 0x00;
	Ftemp.DATA[1] = 0x11;
	Ftemp.DATA[2] = 0x22;
	Ftemp.DATA[3] = 0x33;
	Ftemp.DATA[4] = 0x44;
	Ftemp.DATA[5] = 0x55;
	Ftemp.DATA[6] = 0x66;
	Ftemp.DATA[7] = 0x77;
	UsasrFrameSend(&Ftemp);
}

/**
 * [recdemo ����ʵ��]
 * @param  str [���յ�ַ]
 * @return     [0:����������ȷ��1:�������ݴ���]
 */
unsigned char recdemo(unsigned char * str)
{
	if(CRC_STM32Check( ((FRAME *)str) ->DATA , ((FRAME *)str)->LEN + ((FRAME *)str)->MOD,((FRAME *)str)->CRC32)!= 0)
	{
		return 1;
	}
	printf("value = %08X\r\n",CRC_STM32Hard (((FRAME *)str) ->DATA, ((FRAME *)str)->LEN + ((FRAME *)str)->MOD));
	return 0;
}


/**
 * [UsasrFrameRec ���ڽ����жϵ��ú���]
 * @param  str [����BUFָ��]
 * @return     [0:��ȷ����]
 */
unsigned char UsasrFrameRec(unsigned char * str)
{
	senddemo();
	return recdemo(str);
//	return 0;
}









/* ------ ----------------- Internal Data ----------------------------------- */
volatile unsigned char frame_rx_buffer[25];

void UsartFrame_Init(void)
{
//	u8 ptrmsg;
	/* -------------- Enable Module Clock Source ----------------------------*/
	RCC_AHB1PeriphClockCmd(RCC_UsartFrame, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_Periph_UsartFrame, ENABLE);
	GPIO_PinAFConfig(GPIO_PORT_UsartFrame,GPIO_PinSource_UsartFrame, GPIO_AF_UsartFrame);

	/* dr16_UsartFrame_mailbox ��ʼ��*/
//	ptrmsg = 1; //!< Channel 0

//	os_mbx_send (UsartFrame_mailbox, &ptrmsg,200);
	/* -------------- Configure GPIO ---------------------------------------*/
	{
		GPIO_InitTypeDef GPIO_InitStructure;
		USART_InitTypeDef USART_InitStructure;
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_UsartFrame ;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
		GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
		GPIO_Init(GPIO_PORT_UsartFrame, &GPIO_InitStructure);
		USART_DeInit(USART_UsartFrame);
		USART_InitStructure.USART_BaudRate = 115200;
		USART_InitStructure.USART_WordLength = USART_WordLength_8b;
		USART_InitStructure.USART_StopBits = USART_StopBits_1;
		USART_InitStructure.USART_Parity = USART_Parity_Even;
		USART_InitStructure.USART_Mode = USART_Mode_Rx;
		USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
		USART_Init(USART_UsartFrame,&USART_InitStructure);
		USART_Cmd(USART_UsartFrame,ENABLE);
		USART_DMACmd(USART_UsartFrame,USART_DMAReq_Rx,ENABLE);
	}
	/* -------------- Configure NVIC ---------------------------------------*/
	{
		NVIC_InitTypeDef NVIC_InitStructure;
		NVIC_InitStructure.NVIC_IRQChannel = DMA_IRQn_UsartFrame;
		NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
		NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
		NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
		NVIC_Init(&NVIC_InitStructure);
	}
	/* -------------- Configure DMA -----------------------------------------*/
	{
		DMA_InitTypeDef DMA_InitStructure;
		DMA_DeInit(DMA_Stream_UsartFrame);
		DMA_InitStructure.DMA_Channel = DMA_Channel_UsartFrame;
		DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&(USART_UsartFrame->DR);
		DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)frame_rx_buffer;
		DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;
		DMA_InitStructure.DMA_BufferSize = 1024;
		DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
		DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
		DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
		DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
		DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
		DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;
		DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;
		DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_1QuarterFull;
		DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
		DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
		DMA_Init(DMA_Stream_UsartFrame,&DMA_InitStructure);
		// DMA_ITConfig(DMA_Stream_UsartFrame,DMA_IT_TC,ENABLE);
		DMA_Cmd(DMA_Stream_UsartFrame,DISABLE);
		USART_ITConfig(USART3, USART_IT_IDLE, ENABLE);//�����ж�,���ڲ���������
	}

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
	GPIO_PinAFConfig(GPIOA,GPIO_PinSource2, GPIO_AF_USART2);
	{
		GPIO_InitTypeDef GPIO_InitStructure;
//		USART_InitTypeDef USART_InitStructure;
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2 ;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
		GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
		GPIO_Init(GPIOA, &GPIO_InitStructure);
		// USART_DeInit(USART2);
		// USART_DMACmd(USART2,USART_DMAReq_Tx|USART_DMAReq_Rx,ENABLE);
	}
	{
// 		DMA_InitTypeDef DMA_InitStructure;
// 		DMA_DeInit(DMA1_Stream6);
// 		DMA_InitStructure.DMA_Channel = DMA_Channel_4;
// 		DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&(USART2->DR);
// //		DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)table;
// 		DMA_InitStructure.DMA_DIR = DMA_DIR_MemoryToPeripheral;
// //		DMA_InitStructure.DMA_BufferSize = 30;
// 		DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
// 		DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
// 		DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
// 		DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
// 		DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
// 		DMA_InitStructure.DMA_Priority = DMA_Priority_Medium;
// 		DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;
// 		DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_1QuarterFull;
// 		DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
// 		DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
// 		DMA_Init(DMA1_Stream6,&DMA_InitStructure);
// //		USART_DMACmd(USART1,USART_DMAReq_Tx,ENABLE);
// 		// DMA_ITConfig(DMA1_Stream6,DMA_IT_TC,ENABLE);
// 		DMA_Cmd(DMA1_Stream6,DISABLE);//��ʼ��ʱҪʧ�ܡ��������ܣ�����
	}
}
void USARTFrame_DMA_Send(uint8_t *pbuffer, uint32_t size)
{

	{
		DMA_Cmd (DMA1_Stream6,DISABLE);
		while (DMA_GetCmdStatus(DMA1_Stream6) != DISABLE){}
	//	DMA1_Stream6->M0AR =  (u32)pbuffer;
	//	DMA1_Stream6->NDTR = size;
		DMA_MemoryTargetConfig(DMA1_Stream6,(u32)pbuffer,DMA_Memory_0);
		DMA_SetCurrDataCounter(DMA1_Stream6,size);
	 	DMA_Cmd (DMA1_Stream6,ENABLE);//ʹ��DMA,��ʼ����
	}
}
// __align(8) u8 USART2_TX_BUF[1024]; 	//���ͻ���,���USART3_MAX_SEND_LEN�ֽ�
// void u2_printf(char* fmt,...)
// {
// 	va_list ap;
// 	va_start(ap,fmt);
// 	vsprintf((char*)USART2_TX_BUF,fmt,ap);
// 	va_end(ap);
// 	USARTFrame_DMA_Send(USART2_TX_BUF, strlen((const char*)USART2_TX_BUF));
// //	for(j=0;j<i;j++)//ѭ����������
// //	{
// //	  while(USART_GetFlagStatus(USART1,USART_FLAG_TC)==RESET);  //�ȴ��ϴδ������
// //		USART_SendData(USART1,(uint8_t)USART1_TX_BUF[j]); 	 //�������ݵ�����3
// //	}
// }



void UsartFrame_mailbox_init(void)
{
	os_mbx_init (&UsartFrame_mailbox, sizeof(UsartFrame_mailbox));//UsartFrame�����ʼ��
}

uint8_t UsartFrame_receive(FRAME **ptrmsg, uint16_t timeout)
{
	return os_mbx_wait(UsartFrame_mailbox, (void **)ptrmsg,200);
}




//��Ƭ���жϲ�����C++�����룬������������
#ifdef __cplusplus
 extern "C" {
#endif
CVStuct *CVValue;
CV_ALL_Stuct CVAllValue;
extern FUZZYPID YawPID,PitchPID;
extern CPID CarFramePID;
u8 cv_flag;
extern short tmeee;
void USART3_IRQHandler(void)
{
//	static FRAME ptrmsg;
	u8 clear = clear;
	static short int temp[4];
	static short flag[2];//	static uint32_t temp;
	static u8 count[2];
	if (USART_GetITStatus(USART_UsartFrame, USART_IT_IDLE) != RESET)//�����ж�,
	{

		if(CRC_STM32Check( ((FRAME *)frame_rx_buffer) ->DATA , ((FRAME *)frame_rx_buffer)->LEN + ((FRAME *)frame_rx_buffer)->MOD,((FRAME *)frame_rx_buffer)->CRC32)!= 0)
		{
			u1_printf("unmatch crc\r\n");
		}
		else
		{

			CVValue = (CVStuct *) (&((FRAME*)frame_rx_buffer)->DATA[0]);
			switch(CVValue->State.ID)
			{
				case 1:

						flag[0] = CVValue->State.Flag;
						// temp[0] = CVValue->CV_X;
						// temp[1] = CVValue->CV_Y;
						CVAllValue.Strike_Angle_X = CVValue->CV_X;// - 1.38782f
						CVAllValue.Strike_Angle_Y = CVValue->CV_Y;
					break;
				case 2:
						flag[1] = CVValue->State.Flag;
						// temp[2] = CVValue->CV_X;
						// temp[3] = CVValue->CV_Y;
						CVAllValue.Strike_Coordinate_X = CVValue->CV_X - 51;
						CVAllValue.Strike_Coordinate_Y = CVValue->CV_Y;
						

					break;
				default:break;

			}

//			(YawPID.Current -  CarFramePID.Current)/22.7556f//����ͷ�Ƕ�
//			cv_x = ((FRAME*)frame_rx_buffer)->DATA[0]<<24|((FRAME*)frame_rx_buffer)->DATA[1]<<16|((FRAME*)frame_rx_buffer)->DATA[2]<<8|((FRAME*)frame_rx_buffer)->DATA[3];
//			cv_y = ((FRAME*)frame_rx_buffer)->DATA[4]<<24|((FRAME*)frame_rx_buffer)->DATA[5]<<16|((FRAME*)frame_rx_buffer)->DATA[6]<<8|((FRAME*)frame_rx_buffer)->DATA[7];
			if(cv_flag == 1)
			{
				if(flag[1] == 1)
				{
					CVPID.SetCurrent(CVAllValue.Strike_Coordinate_X);
					CVPitchPID.SetCurrent(CVAllValue.Strike_Coordinate_Y);
					flag[1] = 0;
				}
				if(flag[0] == 1)
				{
//					CVPID.SetCurrent(CVAllValue.Strike_Coordinate_X);
//					CVPID.AdjustPID();
					if(myabs(CVAllValue.Strike_Coordinate_X)<(30))
					{
						bsp_LedToggle(3);
					}
					else
					{
						bsp_LedOn(3);
					}
					YawPID.SetTarget( (YawPID.Current -  CarFramePID.Current ) - (CVAllValue.Strike_Angle_X/100.0f)*22.7556f + CVPID.Out) ;
					
					PitchPID.SetTarget(0.130883442399745*CVAllValue.Strike_Angle_Y+2.377947784543123e+03 - CVPitchPID.Out);
					flag[0] = 0;
					count[0] = 0;
				}
				else count[0]++;
				if(count[0] == 15)
				{
					CVPID.ITerm = 0;
					CVPitchPID.ITerm = 0;
					YawPID.SetTarget( (YawPID.Current -  CarFramePID.Current));
					count[0] = 0;
				}
//				if(myabs(CVAllValue.Strike_Coordinate_Y)<3)
//					u1_printf("%d\t%d\r\n",CVAllValue.Strike_Angle_Y,tmeee);
//				ANO_Data1_Send(0xf1,CVAllValue.Strike_Coordinate_X);
//				u1_printf("%x\t%x\t%d\t%d\t%d\t%d\r\n",CVValue->State.ID,CVValue->State.Flag,CVAllValue.Strike_Angle_X,CVAllValue.Strike_Angle_Y,\
			CVAllValue.Strike_Coordinate_X,CVAllValue.Strike_Coordinate_Y\
			);
			}
//			u1_printf("%d\t%d\r\n",YawPID.Current,CarFramePID.Current);
//			u1_printf("%d\t%d\r\n",Get_cv_x(),Get_cv_y());
//			if(CVValue->State.ID==2)
//			u1_printf("%x\t%d\t%d\r\n",CVValue->State.Flag,CVAllValue.Strike_Angle_X,CVAllValue.Strike_Angle_Y);
//			u1_printf("%x\t%x\t%d\t%d\t%d\t%d\r\n",CVValue->State.ID,CVValue->State.Flag,temp[0],temp[1],\
//			temp[2],temp[3]\
//			);

			

		}
		DMA_Cmd(DMA_Stream_UsartFrame,DISABLE);//DMAʧ��
		while(DMA_GetCmdStatus(DMA_Stream_UsartFrame));//����Ƿ�ʧ�ܳɹ���DMAʧ��ʱ��Ҫ�ȴ�����ʱ���ʧ�ܳɹ�
		DMA_SetCurrDataCounter(DMA_Stream_UsartFrame,1024);//���ݴ�����
		DMA_Cmd(DMA_Stream_UsartFrame,ENABLE);//DMA����ʹ��
		clear = USART_UsartFrame->SR;//������Ϊ��������жϱ�־
		clear = USART_UsartFrame->DR;//������Ϊ��������жϱ�־
	}
}

u8 Get_cv_flag(void)
{
	return cv_flag;
}
void Set_cv_flag(u8 tflag)
{
	cv_flag = tflag;
}

#ifdef __cplusplus
}
#endif
