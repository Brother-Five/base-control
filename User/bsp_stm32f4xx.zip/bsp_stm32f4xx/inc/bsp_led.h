/*
*********************************************************************************************************
*
*	ģ������ : LEDָʾ������ģ��
*	�ļ����� : bsp_led.h
*	��    �� : V1.0
*	˵    �� : ͷ�ļ�
*
*********************************************************************************************************
*/

#ifndef __BSP_LED_H
#define __BSP_LED_H

#ifdef __cplusplus
 extern "C" {
#endif

//#include "..\SYSTEM\sys\sys.h"

/************************************************************************************************/
/**************************************** �ӿڷָ��� ********************************************/
/************************************************************************************************/
#define RCC_ALL_LED 	(RCC_AHB1Periph_GPIOC | RCC_AHB1Periph_GPIOB )
#define __LED1
#define GPIO_PORT_LED1  GPIOC
#define GPIO_PIN_LED1	GPIO_Pin_13
//#define LED1 			PCout(13)

 #define __LED2
#define GPIO_PORT_LED2  GPIOB
#define GPIO_PIN_LED2	GPIO_Pin_15
//#define LED2			PBout(15)

// #define __LED3
#define GPIO_PORT_LED3  GPIOB
#define GPIO_PIN_LED3	GPIO_Pin_15
//#define LED3 			PCout(13)

// #define __LED4
#define GPIO_PORT_LED4  GPIOC
#define GPIO_PIN_LED4	GPIO_Pin_13
//#define LED4 			PCout(13)
/************************************************************************************************/
/**************************************** �ӿڷָ��� ********************************************/
/************************************************************************************************/

/* ���ⲿ���õĺ������� */
void bsp_InitLed(void);
void bsp_LedOn(uint8_t _no);
void bsp_LedOff(uint8_t _no);
void bsp_LedToggle(uint8_t _no);
uint8_t bsp_IsLedOn(uint8_t _no);


#ifdef __cplusplus
}
#endif

#endif
