/*
*********************************************************************************************************
*
*	模块名称 : 外部中断模块
*	文件名称 : bsp_exit.h
*	版    本 : V1.0
*	说    明 : 外部中断触发方式头文件
*	修改记录 :
*
*********************************************************************************************************
*/

#ifndef __BSP_EXIT_H
#define __BSP_EXIT_H
#ifdef __cplusplus
 extern "C" {
#endif
#include "bsp.h"
#include "..\SYSTEM\sys\sys.h"
extern void TIM_CallBack3(void);
extern void TIM_CallBack4(void);
//#define USE_EXIT_LINE_0
#define USE_EXIT_LINE_5
#define EXIT_LINE_5_PortSource 		EXTI_PortSourceGPIOC
#define EXIT_LINE_5_Line    		EXTI_Line5
#define EXIT_LINE_5_Trigger 		EXTI_Trigger_Falling
#define EXIT_LINE_5_Mode 		    ONCE_MODE               //1:只触发一次 0：连续可触发
#define EXIT_LINE_5_CallBack 		(void *)TIM_CallBack3;

void bsp_InitEXTI(void);
void ExtiConfiguration(uint8_t EXTI_PortSourceGPIOx,uint8_t EXTI_PinSourcex,EXTITrigger_TypeDef _EXTITrigger,void * _pCallBack,MODE_T _mode);

void EXTI_Cmd(uint32_t Linex,FunctionalState NewState);

#ifdef __cplusplus
 }
#endif

#endif

/***************************** 安富莱电子 www.armfly.com (END OF FILE) *********************************/
